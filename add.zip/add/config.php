<?php
#قاعدة البيانات
$db = mysqli_connect(
  "localhost",
  "EL7OT", #اسم المستخدم
  "A05525693269Mm*", #كلمة المرور
  "elmagek" #قاعدة البيانات
);


?>